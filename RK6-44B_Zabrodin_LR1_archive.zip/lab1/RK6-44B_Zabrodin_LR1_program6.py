import numpy as np
import matplotlib.pyplot as plt

dno_file = 'RK6-44B_Zabrodin_LR1_data6.txt'  # имя файла числовых данных

file = open(dno_file)
xval = []
yval = []

for data in file:
    xyvals = data.split()
    if len(xyvals) == 2:
        xval.append(float(data.split()[0]))
        yval.append(float(data.split()[1]))

xval = np.array(xval)
yval = np.array(yval)

plt.title("Zabrodin - Experiment 6")
plt.xlabel("I(R1)")
plt.ylabel("U(R1)")
plt.grid()
plt.plot(xval, yval)
plt.show()
